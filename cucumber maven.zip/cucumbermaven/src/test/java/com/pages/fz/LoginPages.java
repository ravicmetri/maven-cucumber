    package com.pages.fz;

	import static org.testng.Assert.assertEquals;
    import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.CacheLookup;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.How;
	
	public class LoginPages
	
	{ 
		 WebDriver driver;
		 	 
		public LoginPages (WebDriver driver)
	{   
	    // Driver from pagefactory is intialized to local driver	
		this.driver=driver;
	}
		 
		//Locating the elements by Using Page Factory
		@FindBy(how=How.XPATH,using=".//*[@id='username']")
		@CacheLookup // looks up all the elements in local memory first
		WebElement username; 
		 
		@FindBy(how=How.ID,using="password")
		@CacheLookup
		WebElement password;
		 
		@FindBy(how=How.XPATH,using=".//*[@id='login_form']/div[7]/button")
		@CacheLookup
		WebElement submit_button;
		 
		 //Method to login into the web App
		public void login_fz1(String uid,String pass)
	{
		
	    username.sendKeys(uid);
		password.sendKeys(pass);
		submit_button.click();
		
       /* assertEquals("Dashboard", driver.getTitle());
        driver.getTitle();*/
        
        if(driver.getPageSource().contains("Welcome"))
        {
 	        System.out.println("Login Is success");
        }
          else
        {
            System.out.println("Login Is failed");
        } 
	} 
		
}


