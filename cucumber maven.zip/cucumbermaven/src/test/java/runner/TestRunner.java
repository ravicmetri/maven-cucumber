package runner;

/**
 * Created by Raviraj on 30/10/2017.
 */
import cucumber.api.CucumberOptions;
import cucumber.api.testng.TestNGCucumberRunner;
//import cucumber.api.testng.CucumberFeatureWrapper;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
 
@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"features"},
        tags = {"~@Ignore"},
        format = {                "pretty",
               /* "html:target/cucumber-reports/cucumber-pretty",
                "json:target/cucumber-reports/CucumberTestReport.json",
                "rerun:target/cucumber-reports/rerun.txt"*/
        })
public class TestRunner {
	
	
}