// Test Case of Login using Page Factory
package stepdefinations;
import java.io.File;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.ExtentXReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.pages.fz.LoginPages;
import com.webfieldez.pages.LoginPage;
import com.webfieldez.utilities.BrowserFactory;

import BrowserUtility.BrowseFactory;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginTest
{ 
	/*ExtentHtmlReporter htmlReporter;
	ExtentReports extent;
	ExtentTest test;*/
    WebDriver driver;
  /*      
    @BeforeTest
    public void startReport()
    {
        //htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") +"/test-output/MyOwnReport.html");
        htmlReporter = new ExtentHtmlReporter("E://RAVIRAJ AUTOMATION//Reports//AdvancedReports9.html");
      
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        extent.setSystemInfo("OS", "Windows");
        extent.setSystemInfo("Host Name", "fieldez");
        extent.setSystemInfo("User Name", "Raviraj Metri");
        //test.assignCategory("Sanity Check");
   	    //test.assignAuthor("Raviraj Metri1");
   	    extent.setSystemInfo("Environment", "Production");
        htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setDocumentTitle("AutomationTesting Reports");
        htmlReporter.config().setReportName("Basic Sanity Check");
        htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
       // htmlReporter.config().setTheme(Theme.DARK);
    }  
    
@Test(priority=1,enabled=true)
public void checkValidUser()
{   
	 WebDriver driver=BrowserFactory.StartBrowser("firefox", "https://www.fieldez.com/emob/login.jsp");
	 ExtentTest test = extent.createTest("TC1: Feildez Web App Login", "Verifying the login");
	 test.log(Status.INFO, "Fieldez Application is Up and Running");
	 
	// Implicit wait commands, It will wait for 10seconds
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

    // Created Page Object using Page Factory
    LoginPage login_page=PageFactory.initElements(driver, LoginPage.class);
 
    // Call the method
    login_page.login_fz("orgauto","test123");
    
    // Implicit wait commands, It will wait for 10seconds
 	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	            
	            if(driver.getPageSource().contains("Welcome"))
	            {
	            	//Assert.assertTrue(true);
	             	test.log(Status.PASS,"Title 'Fieldez.com' is Verified");
	             	 
	            }
	                  else if(driver.getPageSource().contains("Invalid username/password!"))
	            {     
	              test.log(Status.FAIL,"Invalid Username and Password");
	             
	            }
	            
	            else if (driver.getPageSource().contains("error"))
	            {     
	              test.log(Status.FATAL,"Server is down");
	              
	            }
	            
	            else 
	            {  
	            	test.log(Status.WARNING,"Automation excution stopped");
	            	
	            }
	            
}
@AfterMethod
public void getResult(ITestResult result)
{
    if(result.getStatus() == ITestResult.FAILURE)
    {
        test.log(Status.FAIL, MarkupHelper.createLabel(result.getName()+" Test case FAILED due to below issues:", ExtentColor.RED));
        test.fail(result.getThrowable());
    }
    else if(result.getStatus() == ITestResult.SUCCESS)
    {
        test.log(Status.PASS, MarkupHelper.createLabel(result.getName()+" Test Case PASSED", ExtentColor.GREEN));
    }
    else
    {
        test.log(Status.SKIP, MarkupHelper.createLabel(result.getName()+" Test Case SKIPPED", ExtentColor.ORANGE));
        test.skip(result.getThrowable());
    }
}
@AfterTest

	    	    public void reports() throws InterruptedException{
	    		    {
	    		    	 extent.flush();
	    		    	 System.setProperty("webdriver.firefox.marionette","E:\\RAVIRAJ AUTOMATION\\Automation\\geckodriver-v0.11.1-win64\\geckodriver.exe");
	    			     driver=new FirefoxDriver();
	    			     driver.manage().timeouts().pageLoadTimeout(10000, TimeUnit.MILLISECONDS);
	    			     driver.get("http://localhost:1337/#\",27017");
	    			     driver.manage().window().maximize();   		    	
	    		    	 extent.flush();
	    		      	 System.setProperty("webdriver.chrome.driver", "E:\\RAVIRAJ AUTOMATION\\chromedriver_win32\\chromedriver.exe");
	    			     driver=new ChromeDriver();
	    			     driver.manage().timeouts().pageLoadTimeout(10000, TimeUnit.MILLISECONDS);  
	    			     driver.get("E://RAVIRAJ AUTOMATION//Reports//AdvancedReports9.html");
	    			     driver.manage().window().maximize();

	    			      		    }     
	            
} }




//------------------------------------------------------------
*/




@Given("^a  page on URL \"([^\"]*)\"$")
public void a_page_on_URL(String arg1) throws Exception {
    // Write code here that turns the phrase above into concrete actions
	
	WebDriver driver=BrowseFactory.StartBrowser("firefox", "https://www.fieldez.com/emob/login.jsp");
    throw new PendingException();
}

@Then("^I should see \"([^\"]*)\" message$")
public void i_should_see_message(String arg1) throws Exception {
    // Write code here that turns the phrase above into concrete actions
	String pageSource = driver.getPageSource();
    if(pageSource.contains("Welcome to FieldEZ")){
        System.out.println("Login into the applicaton now");
    }else{
        System.out.println("Unable to login as this page is not login page");
    }
 // Implicit wait commands, It will wait for 10seconds
 	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    throw new PendingException();
}
@When("^I fill in \"([^\"]*)\" with \"([^\"]*)\" and \"([^\"]*)\"test(\\d+)\"$")
public void i_fill_in_with_and_test(String arg1, String arg2, String arg3, int arg4) throws Exception {
    // Write code here that turns the phrase above into concrete actions
	
	// Created Page Object using Page Factory
    LoginPages login_pages=PageFactory.initElements(driver, LoginPages.class);
 
    // Call the method
    login_pages.login_fz1("orgauto","test123");
    throw new PendingException();
}

@Then("^Welcome Username should be displayed$")
public void welcome_Username_should_be_displayed() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	
	// Implicit wait commands, It will wait for 10seconds
	 	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		            
		            if(driver.getPageSource().contains("Welcome"))
		            {
		            	//Assert.assertTrue(true);
		             	//test.log(Status.PASS,"Title 'Fieldez.com' is Verified");
		            	
		            	System.out.println("Fieldez.com' is Verified");
		             	 
		            }
		                  else if(driver.getPageSource().contains("Invalid username/password!"))
		            {     
		             // test.log(Status.FAIL,"Invalid Username and Password");
		                	  System.out.println("Fieldez.com' is Verified");
		            }
		            
		            else if (driver.getPageSource().contains("error"))
		            {     
		            //  test.log(Status.FATAL,"Server is down");
		            	System.out.println("Fieldez.com' is Verified");
		            }
		            
		            else 
		            {  
		            	//test.log(Status.WARNING,"Automation excution stopped");
		            	System.out.println("Fieldez.com' is Verified");
		            }
		            
    throw new PendingException();
}

}